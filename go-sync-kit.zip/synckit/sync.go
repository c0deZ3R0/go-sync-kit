// Package sync provides a generic event-driven synchronization system
// for distributed applications. It supports offline-first architectures
// with conflict resolution and pluggable storage backends.
package synckit

import (
	"context"
	"log/slog"
	"time"

	"github.com/c0deZ3R0/go-sync-kit/cursor"
	"github.com/c0deZ3R0/go-sync-kit/synckit/statemachine"
	"github.com/c0deZ3R0/go-sync-kit/synckit/types"
	"go.opentelemetry.io/otel/trace"
)

// Event represents a syncable event in the system.
// This interface should be implemented by user's event types.
type Event = types.Event

// Version represents a point-in-time snapshot for sync operations.
// Users can implement different versioning strategies (timestamps, hashes, vector clocks).
type Version = types.Version

// EventWithVersion pairs an event with its version information
type EventWithVersion = types.EventWithVersion

// EventStore provides persistence for events.
// Implementations can use any storage backend (SQLite, BadgerDB, PostgreSQL, etc.).
type EventStore interface {
	// Store persists an event to the store
	Store(ctx context.Context, event Event, version Version) error

	// Load retrieves all events since the given version
	Load(ctx context.Context, since Version) ([]EventWithVersion, error)

	// LoadByAggregate retrieves events for a specific aggregate since the given version
	LoadByAggregate(ctx context.Context, aggregateID string, since Version) ([]EventWithVersion, error)

	// LatestVersion returns the latest version in the store
	LatestVersion(ctx context.Context) (Version, error)

	// ParseVersion converts a string representation into a Version
	// This allows different storage implementations to handle their own version formats
	ParseVersion(ctx context.Context, versionStr string) (Version, error)

	// Close closes the store and releases resources
	Close() error
}

// ConflictResolver is now defined in conflict.go

// Transport handles the actual network communication between clients and servers.
// Implementations can use HTTP, gRPC, WebSockets, NATS, etc.
type Transport interface {
	// Push sends events to the remote endpoint
	Push(ctx context.Context, events []EventWithVersion) error

	// Pull retrieves events from the remote endpoint since the given version
	Pull(ctx context.Context, since Version) ([]EventWithVersion, error)

	// GetLatestVersion efficiently retrieves the latest version from remote without pulling events
	GetLatestVersion(ctx context.Context) (Version, error)

	// Subscribe listens for real-time updates (optional for polling-based transports)
	Subscribe(ctx context.Context, handler func([]EventWithVersion) error) error

	// Close closes the transport connection
	Close() error
}

// CursorTransport extends Transport with cursor-based capabilities.
type CursorTransport interface {
	Transport

	// PullWithCursor retrieves events using a cursor-based pagination strategy.
	// Returns events, next cursor, and any error.
	PullWithCursor(ctx context.Context, since cursor.Cursor, limit int) ([]EventWithVersion, cursor.Cursor, error)
}

// RetryConfig configures the retry behavior for sync operations
type RetryConfig struct {
	// MaxAttempts is the maximum number of retry attempts
	MaxAttempts int

	// InitialDelay is the initial delay between retries
	InitialDelay time.Duration

	// MaxDelay is the maximum delay between retries
	MaxDelay time.Duration

	// Multiplier is the factor by which the delay increases
	Multiplier float64
}

// SyncOptions configures the synchronization behavior
type SyncOptions struct {
	// LastCursorLoader loads the last saved cursor for cursor-based syncs
	LastCursorLoader func() cursor.Cursor

	// CursorSaver saves the latest cursor after a successful sync
	CursorSaver func(cursor.Cursor) error

	// PushOnly indicates this client should only push events, not pull
	PushOnly bool

	// PullOnly indicates this client should only pull events, not push
	PullOnly bool

	// ConflictResolver to use for handling conflicts
	ConflictResolver ConflictResolver

	// Filter can be used to sync only specific events
	Filter func(Event) bool

	// BatchSize limits how many events to sync at once
	BatchSize int

	// SyncInterval for automatic periodic sync (0 disables)
	SyncInterval time.Duration

	// RetryConfig configures retry behavior for sync operations
	RetryConfig *RetryConfig

	// EnableValidation enables additional validation checks during sync
	EnableValidation bool

	// Timeout sets the maximum duration for sync operations
	Timeout time.Duration

	// EnableCompression enables data compression during transport
	EnableCompression bool

	// MetricsCollector for observability hooks (optional)
	MetricsCollector MetricsCollector

	// Tracer for distributed tracing (optional)
	Tracer interface {
		// StartSyncOperation starts a new span for a sync operation
		StartSyncOperation(ctx context.Context, operation string) (context.Context, trace.Span)
		// StartTransportOperation starts a new span for transport operations
		StartTransportOperation(ctx context.Context, operation, transport string) (context.Context, trace.Span)
		// StartStorageOperation starts a new span for storage operations
		StartStorageOperation(ctx context.Context, operation, storageType string) (context.Context, trace.Span)
		// StartConflictResolution starts a new span for conflict resolution
		StartConflictResolution(ctx context.Context, strategy string) (context.Context, trace.Span)
		// RecordError records an error on a span
		RecordError(span trace.Span, err error, description string)
		// SetSyncResult sets sync result attributes on a span
		SetSyncResult(span trace.Span, eventsPushed, eventsPulled, conflictsResolved int)
	}
}

// SyncManager coordinates the synchronization process between local and remote stores.
// This is the main entry point for the sync package.
//
// Deprecated: SyncManager is deprecated. Use SyncNode instead, which provides
// the same functionality with a cleaner API. See node.go for the preferred
// interface and NewNode() for the constructor.
type SyncManager interface {
	// Sync performs a bidirectional sync operation
	Sync(ctx context.Context) (*SyncResult, error)

	// Push sends local events to remote
	Push(ctx context.Context) (*SyncResult, error)

	// Pull retrieves remote events to local
	Pull(ctx context.Context) (*SyncResult, error)

	// StartAutoSync begins automatic synchronization at the configured interval
	StartAutoSync(ctx context.Context) error

	// StopAutoSync stops automatic synchronization
	StopAutoSync() error

	// Subscribe to sync events (optional)
	Subscribe(handler func(*SyncResult)) error

	// Close shuts down the sync manager
	Close() error
}

// SyncResult provides information about a completed sync operation
type SyncResult struct {
	// EventsPushed is the number of events sent to remote
	EventsPushed int

	// EventsPulled is the number of events received from remote
	EventsPulled int

	// ConflictsResolved is the number of conflicts that were resolved
	ConflictsResolved int

	// Errors contains any non-fatal errors that occurred during sync
	Errors []error

	// StartTime is when the sync operation began
	StartTime time.Time

	// Duration is how long the sync took
	Duration time.Duration

	// LocalVersion is the local version after sync
	LocalVersion Version

	// RemoteVersion is the remote version after sync
	RemoteVersion Version
}

// NewSyncManager creates a new sync manager with the provided components
func NewSyncManager(store EventStore, transport Transport, opts *SyncOptions, logger *slog.Logger, projectionConfig *ProjectionConfig) SyncManager {
	if opts == nil {
		opts = &SyncOptions{
			BatchSize: 100,
			RetryConfig: &RetryConfig{
				MaxAttempts:  3,
				InitialDelay: 100 * time.Millisecond,
				MaxDelay:     5 * time.Second,
				Multiplier:   2.0,
			},
			MetricsCollector: &NoOpMetricsCollector{}, // Default no-op collector
		}
	}

	// Set default metrics collector if none provided
	if opts.MetricsCollector == nil {
		opts.MetricsCollector = &NoOpMetricsCollector{}
	}

	// Set default DynamicResolver with LWW fallback if none provided
	if opts.ConflictResolver == nil {
		defaultResolver, err := NewDynamicResolver(
			WithFallback(&LastWriteWinsResolver{}),
			WithLogger(logger),
		)
		if err != nil {
			// This should never happen with a simple LWW fallback,
			// but we handle it gracefully
			logger.Warn("Failed to create default DynamicResolver, using LWW directly", "error", err)
			opts.ConflictResolver = &LastWriteWinsResolver{}
		} else {
			opts.ConflictResolver = defaultResolver
		}
	}

	// Create state machine with observability integration
	stateMachine, err := createSyncStateMachine(opts.MetricsCollector, opts.Tracer, logger)
	if err != nil {
		// Log the error but don't fail - state machine is optional enhancement
		logger.Warn("Failed to create sync state machine, continuing without state tracking", "error", err)
	}

	sm := &syncManager{
		store:            store,
		transport:        transport,
		options:          *opts,
		logger:           logger,
		stateMachine:     stateMachine,
		projectionConfig: projectionConfig,
	}

	// Initialize projection worker pool if projections are configured
	if projectionConfig != nil && projectionConfig.RunOnSync && len(projectionConfig.Runners) > 0 {
		sm.projectionPool = make(chan struct{}, projectionConfig.MaxWorkers)
		logger.Info("Projection support enabled",
			"runner_count", len(projectionConfig.Runners),
			"max_workers", projectionConfig.MaxWorkers,
			"timeout", projectionConfig.Timeout,
		)
	}

	return sm
}

// createSyncStateMachine creates a state machine with observability integration
func createSyncStateMachine(metricsCollector MetricsCollector, tracer interface{}, logger *slog.Logger) (statemachine.StateMachine[SyncState], error) {
	// Create the basic state machine
	basicStateMachine, err := NewSyncStateMachine()
	if err != nil {
		return nil, err
	}

	// If no observability components provided, return basic state machine
	if metricsCollector == nil && tracer == nil {
		return basicStateMachine, nil
	}

	// Create observability adapters
	var stateMetrics statemachine.StateMetricsCollector
	var stateTracer statemachine.StateTracer
	var healthUpdater statemachine.StateHealthUpdater

	// Setup metrics adapter
	if metricsCollector != nil {
		stateMetrics = statemachine.NewSyncKitMetricsAdapter(metricsCollector)
	}

	// Setup tracing adapter if available
	if tracer != nil {
		// Try to cast to the expected tracer interface
		if syncTracer, ok := tracer.(interface {
			StartSyncOperation(ctx context.Context, operation string) (context.Context, trace.Span)
			RecordError(span trace.Span, err error, description string)
			SetSyncResult(span trace.Span, eventsPushed, eventsPulled, conflictsResolved int)
		}); ok {
			stateTracer = statemachine.NewSyncKitTracerAdapter(syncTracer)
		}
	}

	// Create default health updater (placeholder for future health check integration)
	if logger != nil {
		healthUpdater = statemachine.NewDefaultStateHealthUpdater(nil) // nil for now, can be enhanced later
	}

	// Create observability hooks
	hooks := statemachine.NewObservabilityHooks[SyncState](
		stateMetrics,
		stateTracer,
		healthUpdater,
		logger,
		"sync_manager",
	)

	// Subscribe observability hooks to the state machine
	basicStateMachine.Subscribe(hooks)

	return basicStateMachine, nil
}
