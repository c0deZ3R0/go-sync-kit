# go-sync-kit

Tiny, composable building blocks for **event sync** in Go.

- ✅ Simple mental model: **Node → Store + Transport (+ Resolver)**
- ⚡ In-memory dev experience (no external deps)
- 🌐 HTTP presets for client/server
- 🔧 Pluggable conflict resolution
- 📦 Production-ready stores/transports

---

## Table of Contents
- [Why go-sync-kit?](#why-go-sync-kit)
- [Install](#install)
- [60-Second Quick Start (In-Memory)](#60-second-quick-start-in-memory)
- [HTTP Client/Server Quick Start](#http-clientserver-quick-start)
- [Core Concepts](#core-concepts)
- [Examples & Docs](#examples--docs)
- [Migration from SyncManager](#migration-from-syncmanager)
- [Stability & Versioning](#stability--versioning)
- [Contributing](#contributing)

---

## Why go-sync-kit?

You have data changing **locally** and **remotely**. You want to:
- push local events, pull remote events,
- resolve conflicts sanely,
- and not wire an entire distributed system framework.

**go-sync-kit** gives you *just enough*:
- A **Node** you start,
- a **Store** where events live,
- a **Transport** that moves them,
- an optional **Resolver** for conflicts.

---

## Install

```bash
go get github.com/c0deZ3R0/go-sync-kit@latest
```

---

## 60-Second Quick Start (In-Memory)

```go
package main

import (
	"context"
	"log"

	"github.com/c0deZ3R0/go-sync-kit/storage/memstore"
	"github.com/c0deZ3R0/go-sync-kit/synckit"
	"github.com/c0deZ3R0/go-sync-kit/transport/memchan"
)

func main() {
	store := memstore.New()
	transport := memchan.New(16)

	node, err := synckit.NewNode(
		synckit.WithStore(store),
		synckit.WithTransport(transport),
		synckit.WithLWW(), // simple conflict resolution
	)
	if err != nil { log.Fatal(err) }
	defer node.Close()

	res, err := node.Sync(context.Background())
	if err != nil { log.Fatal(err) }

	log.Printf("pushed=%d pulled=%d conflicts=%d",
		res.EventsPushed, res.EventsPulled, res.ConflictsResolved)
}
```

Want to see more in-memory patterns (hub, subscriptions)? See [`examples/inmem`](examples/inmem).

---

## HTTP Client/Server Quick Start

**Server**
```go
// examples/http_server/main.go
store, _ := sqlite.New(&sqlite.Config{DataSourceName: "server.db"})
transport := httptransport.NewTransport("", nil, nil, nil) // server mode
node, _ := synckit.NewHTTPServerNode(store, transport)
handler := httptransport.NewSyncHandler(store, nil, nil, nil)

http.Handle("/sync", handler)
log.Fatal(http.ListenAndServe(":8080", nil))
```

**Client**
```go
// examples/http_client/main.go
store, _ := sqlite.New(&sqlite.Config{DataSourceName: "client.db"})
transport := httptransport.NewTransport("http://localhost:8080/sync", nil, nil, nil)
node, _ := synckit.NewHTTPClientNode(store, transport)

res, _ := node.Sync(context.Background())
// pushed/pulled metrics in res
```

- **Full walk-throughs**: [`examples/HTTP_EXAMPLES.md`](examples/HTTP_EXAMPLES.md)
- **Production server with graceful shutdown**: [`examples/http_server/main_production.go`](examples/http_server/main_production.go)

---

## Core Concepts

**SyncNode** – the participant you run. It exposes:
- `Sync(ctx)`, `Push(ctx)`, `Pull(ctx)`
- `StartAutoSync(ctx)`, `StopAutoSync()`, `Subscribe(...)`, `Close()`

**Store** – event persistence (e.g. `memstore`, `sqlite`, `postgres`).

**Transport** – how events move (e.g. HTTP request/response, in-memory `memchan`, SSE for real-time subscriptions).

**ConflictResolver** – strategy for conflicts (e.g. LWW). Pluggable.

---

## Examples & Docs

- **In-memory quickstart**: [`examples/inmem`](examples/inmem)
- **HTTP client/server**: [`examples/http_client`](examples/http_client), [`examples/http_server`](examples/http_server)
- **Real-time SSE overview**: see notes in [`examples/HTTP_EXAMPLES.md`](examples/HTTP_EXAMPLES.md)

**Advanced topics:**
- **Observability (metrics/tracing)**: [`examples/observability_*`](examples/)
- **Health checks**: [`examples/health_check_example.go`](examples/health_check_example.go)

---

## Migration from SyncManager

SyncNode is the preferred API. It's a drop-in façade over SyncManager:

```go
// old (still works)
m, _ := synckit.NewManager(/* options */)

// new (preferred)
n, _ := synckit.NewNode(/* same options */)
```

SyncManager remains for compatibility but is deprecated in docs.

---

## Stability & Versioning

- **Semantic versioning**
- **Deprecated symbols** kept for at least one minor release before removal  
- **Go ≥ 1.21** recommended

---

## Contributing

PRs welcome! Please:
- keep examples minimal,
- prefer docs in `/examples` or `/docs`,
- add tests for new store/transport/resolver integrations.

