module github.com/c0deZ3R0/go-sync-kit/examples/http_client

go 1.24.4

replace github.com/c0deZ3R0/go-sync-kit => ../..

require github.com/c0deZ3R0/go-sync-kit v0.0.0-00010101000000-000000000000

require (
	github.com/mattn/go-sqlite3 v1.14.30 // indirect
	go.opentelemetry.io/otel v1.37.0 // indirect
	go.opentelemetry.io/otel/trace v1.37.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
